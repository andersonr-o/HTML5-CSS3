const form = document.querySelector('.form')

form.addEventListener('submit', e => {
    e.preventDefault();
    const inputPeso = e.target.querySelector('#peso')// pegando o input de outra maneira
    const inputAltura = e.target.querySelector('#altura')

    const peso = Number(inputPeso.value)
    const altura = Number(inputAltura.value)

    if (!peso){
        setResultado(`Peso inválido`, false)
        return; // return para caso seja válido a função não continue rodando
    }

    if (!altura){
        setResultado('Altura inválida', false)
        return;
    }

    const imc = getImc(peso, altura)
    const nivelImc = getNivelImc(imc)

    const mensagem = `Seu IMC é ${imc} (${nivelImc})`

    setResultado(mensagem, true)
})

function getImc(peso, altura){
    const imc = peso / altura**2
    return imc.toFixed(2)
}

function getNivelImc(imc){
    const nivel = ['Abaixo do peso', 'Peso normal', 'Sobrepeso', 'Obesidade grau 1', 'Obesidade grau 2', 'Obesidade grau 3'];

    if (imc > 39.9) return nivel[5];
    if (imc > 34.9) return nivel[4];
    if (imc > 29.9) return nivel[3];
    if (imc > 24.9) return nivel[2];
    if (imc > 18.4) return nivel[1];
    if (imc < 18.5) return nivel[0];
}

function criaP (){
    const p = document.createElement('p') // Criando parágrafo pelo JS
    return p;
}

function setResultado (msg, isValid){
    const resultado = document.querySelector('#result') // Trazendo a div do HTML
    resultado.innerHTML = '';
    
    const p = criaP();

    if (isValid){ // Não precisa colocar if (isValid == true) porque o JS já entende
        p.classList.add('paragrafo-resultado') // Adicionando class pelo JS
    } else{
        p.classList.add('bad');
    }

    p.innerHTML = msg;
    resultado.appendChild(p) // Inserindo o parágrafo criado na div do HTML
}